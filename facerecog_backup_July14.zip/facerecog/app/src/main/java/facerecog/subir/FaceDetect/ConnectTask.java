package facerecog.subir.FaceDetect;

import android.os.AsyncTask;
import android.util.Log;

import static facerecog.subir.FaceDetect.MainActivity.mTcpClient;

/**
 * Created by subir on 4/30/17.
 */

public class ConnectTask extends AsyncTask<String, String, TcpClient> { //arguments: param for doInBackground, Progress, Result

    @Override
    protected TcpClient doInBackground(String... message) {//the argument passed to execute() sits in 'message'

        //we create a TCPClient object
        mTcpClient = new TcpClient(new TcpClient.OnMessageReceived() {
            @Override
            //here the messageReceived method is implemented
            public void messageReceived(String message) {
                //this method calls the onProgressUpdate
                publishProgress(message);//I am choosing to send the received 'message' as progressUpdate parameter (String) to print
            }
        });
        mTcpClient.run();
        Log.d("ConnectTask", "After Run");

        return null;
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
        //response received from server
        Log.d("test", "response " + values[0]);
        //process server response here....

    }
}