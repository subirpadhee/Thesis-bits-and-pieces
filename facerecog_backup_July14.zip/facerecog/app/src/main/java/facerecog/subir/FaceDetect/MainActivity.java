package facerecog.subir.FaceDetect;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    public static TcpClient mTcpClient = null;
    private Button btnSend;
    private Button btnCam;
    private boolean flag = true;
    static final int REQUEST_VIDEO_CAPTURE = 1;
    private String videoPath = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSend = (Button) findViewById(R.id.btnSend);
        btnCam = (Button) findViewById(R.id.btnCam);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                new ConnectTask().execute("RANDOM");

                while(flag) {
                    //Log.e("MainActivity", "After Execute");
                    if (mTcpClient != null) {
                        Log.d("MainActivity", "About to send message");
                        /*byte [] sendArray = new byte [1024];
                        int numBytesRead = 0;
                        File myFile = new File ("/storage/emulated/0/Pictures/CameraSample/video.mp4");
                        try{
                            FileInputStream fis = new FileInputStream(myFile);
                            numBytesRead = fis.read(sendArray);
                            while(numBytesRead != 0) {
                                System.out.println("Sending...");
                                mTcpClient.sendMessage(sendArray);
                                numBytesRead = fis.read(sendArray);
                            }
                        } catch(Exception e){

                        }*/

                        if (mTcpClient != null) {
                            mTcpClient.stopClient();
                        }
                        flag = false;
                    } else {
                        //Log.e("MainActivity", "TCP client is NULL");
                    }
                }
            }
        });

        btnCam.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
                }

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intentRcvd) {
        if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK) {
            Uri videoUri = intentRcvd.getData();
            Toast.makeText(this, videoUri.getPath().toString(), Toast.LENGTH_LONG).show();
            Log.d("PATH: ", videoUri.getPath().toString());
            videoPath = getRealPathFromURI(videoUri);
            Log.d("PATH_REAL: ", videoPath.toString());

            try {

                FileInputStream fis = new FileInputStream(videoPath);

                File tmpFile = new File(Environment.getExternalStorageDirectory(),"video.mp4");
                Log.d("PATH_DEST: ", tmpFile.toString());

                //save the video to the File path
                FileOutputStream fos = new FileOutputStream(tmpFile);

                byte[] buf = new byte[1024];
                int len;
                while ((len = fis.read(buf)) > 0) {
                    fos.write(buf, 0, len);
                }
                fis.close();
                fos.close();
            } catch (IOException io_e) {
                Log.d("PATH_ERROR: ", io_e.toString());
            }
        }
    }

    public String getRealPathFromURI(Uri contentUri) {
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(contentUri, proj, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
}

